function App () {
  return (
    <div>示例</div>
  )
}

ReactDOM.render(<App />, document.getElementById('content'))