function App () {
  return (
    <div>统计</div>
  )
}

ReactDOM.render(<App />, document.getElementById('content'))